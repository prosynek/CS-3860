
#Video Recordings lab 3

Video_Recordings (
recording_id,
director,
title,
category,
image_name,
duration,
rating,
year_released,
price,
stock_count
);


Video_Categories (
id,
name
);


Video_Actors (
id,
name,
recording_id
);
